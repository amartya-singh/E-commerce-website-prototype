<!--
Developer: Amartya Singh
Project From Internshala

Project Name: Lifestyle Store
page: This is footer inclusion code
-->
<footer>
    <div class="container" style="margin-top: 10px;">
        <center>
            <p>Copyright &copy; Lifestyle Store. All rights Reserved | Contact Us: +91 90000 00000</p>
        </center>
    </div>
</footer>

